# 🌻 PageTurners - Book Club Platform

Your complete book club platform with voting, submissions, and beautiful design.

## Quick Start:
1. Upload all files to your web hosting
2. Visit your domain
3. Login with demo/demo
4. Start using with your book club!

## Features:
- ✅ Book voting system
- ✅ Book submissions
- ✅ Beautiful sunflower design
- ✅ Mobile-friendly
- ✅ Dashboard with statistics

See `DEPLOYMENT_GUIDE.md` for detailed instructions.

**Demo Login:** username: `demo`, password: `demo`

